# Code Review Assistant
Automated code review API using FastAPI + OpenAI GPT models.
Run with:
uvicorn main:app --reload
