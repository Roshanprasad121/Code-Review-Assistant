#!/usr/bin/env bash
uvicorn main:app --reload &
sleep 3
curl -X POST "http://127.0.0.1:8000/upload" -F "file=@demo/example.py"
kill $(lsof -t -i:8000)
