def greet(name):
    print(f"Hello, {name}")
if __name__ == "__main__":
    greet("World")
