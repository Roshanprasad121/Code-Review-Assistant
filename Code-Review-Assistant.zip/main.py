import os
import uuid
from datetime import datetime
from typing import List
from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from sqlalchemy.orm import Session
import openai, uvicorn
from models import ReportOut, Report as ReportModel, Base
from db import SessionLocal, engine

Base.metadata.create_all(bind=engine)
openai.api_key = os.getenv("OPENAI_API_KEY")

app = FastAPI(title="Code Review Assistant API")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def build_prompt(filename, code):
    return f"Review {filename} for readability, modularity, and bugs.\n\n{code}"

@app.post("/upload", response_model=ReportOut)
async def upload_and_analyze(file: UploadFile = File(...), db: Session = Depends(get_db)):
    contents = await file.read()
    code = contents.decode("utf-8")
    prompt = build_prompt(file.filename, code)
    response = openai.ChatCompletion.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        messages=[{"role": "user", "content": prompt}]
    )
    review = response.choices[0].message.content.strip()
    report = ReportModel(id=str(uuid.uuid4()), filename=file.filename, uploaded_at=datetime.utcnow(), review_text=review, raw_code=code)
    db.add(report)
    db.commit()
    db.refresh(report)
    return ReportOut.from_orm(report)

@app.get("/reports", response_model=List[ReportOut])
def list_reports(db: Session = Depends(get_db)):
    return [ReportOut.from_orm(r) for r in db.query(ReportModel).all()]

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
