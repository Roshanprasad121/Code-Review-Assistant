from datetime import datetime
from pydantic import BaseModel
from typing import Optional
from sqlalchemy import Column, String, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Report(Base):
    __tablename__ = "reports"
    id = Column(String, primary_key=True, index=True)
    filename = Column(String, nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    review_text = Column(Text, nullable=False)
    raw_code = Column(Text, nullable=True)

class ReportOut(BaseModel):
    id: str
    filename: str
    uploaded_at: datetime
    review_text: str
    class Config:
        orm_mode = True
