from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_upload_endpoint():
    files = {"file": ("example.py", "print('hello world')")}
    response = client.post("/upload", files=files)
    assert response.status_code == 200
